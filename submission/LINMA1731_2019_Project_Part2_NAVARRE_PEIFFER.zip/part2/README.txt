Please read the full document before trying to execute our code.

For the first part of the project, we started by computing our function EstimateGamma using Julia.

Then, for the second part, we received Matlab files. To be able to use our previous code, written in Julia, we decided to translate the main file from Matlab too Julia. Hence, you have to use this file LINMA1731_2019_project_main.jl to execute our code.

Nevertheless, our ParticleFilter function is written in Matlab, due to the fact that this function calls many times the StateUpdate function, also written in Matlab. Hence, for an improvement of the time execution, we decided to write the second part of the project in Matlab.

Thank you for your comprehension.

Louis & Gilles.